## Overview

This is an example that demonstrates how to use the JMS client APIs to 
accomplish basic messaging tasks.

The build.xml file provides targets for rebuilding the examples and for 
launching them.